
<?php
class Voiture
{
 public $_marque;
 public $_nombre_de_place_assise;
 public $_nombre_de_roue;
 public $_couleur;
 public $_plaque_d_imatriculation;
}
