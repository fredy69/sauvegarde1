<?php
class Console
{
 public $_marque;
 public $_nombre_de_jeux;
 public $_manette;
 
}
