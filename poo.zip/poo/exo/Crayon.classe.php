<?php
class Crayon
{
 public $_couleur;
 public $_type;
 public $_quantités;

}
