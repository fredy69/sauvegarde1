<?php
class Club
{
 public $_équipe;
 public $_joueur;
 public $_poste;
 public $_role;
}
