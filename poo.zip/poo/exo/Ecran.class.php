<?php
class Ecran
{
 public $_marque;
 public $_référence_de_l_écran;
 public $_taille;
 public $_numero_de_série;

}
