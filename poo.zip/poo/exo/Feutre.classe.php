<?php
class Feutre
{
 public $_pointe;
 public $_couleur;
 public $_quantité;

}
