<?php
class Moto
{
 public $_marque;
 public $_couleur;
 public $_plaque_d_imatriculation;

}
