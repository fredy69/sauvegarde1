<?php
class Film
{
 public $_type;
 public $_duree;
 public $_acteurs;
 public $_realisateurs;
 public $_support;
 public $_note;
}
