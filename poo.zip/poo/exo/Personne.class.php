<?php
class Personne
{
 public $_non;
 public $_prenon;
 public $_age;
 public $_sexe;
}
