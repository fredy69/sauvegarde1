
ZTEIN

PAGE 1

  <?php

abstract class LotissementAbstract
{
	const ADRESSE = 'rue Pôle Pixel';
	const VILLE = 'Villeurbanne';
	const CODE_POSTAL = 69100;
}

class Maison extends LotissementAbstract
{
    private $_nb_pieces;
    private $_superficie;
    private $_etage;
    private $_jardin;
    private $_nb_occupant;
    private $_nom_occupants = array();
    private $_numero ;
    private $_prix;
    private $_piscine;

    public function __construct($piece, $superficie, $etage, $jardin, $occupant, $nom_occupants, $numero , $prix, $piscine = false)
    {
        $this->_nb_pieces = $piece;
        $this->_superficie = $superficie;
        $this->_etage = $etage;
        $this->_jardin = $jardin;
        $this->_nb_occupant = $occupant;
        array_push($this->_nom_occupants, $nom_occupants);
        $this->_numero = $numero;
        $this->_prix = $prix;
        $this->_piscine = $piscine;
    }

    public function __get($name){
        $this->$name;
    }
    public function __set($name, $value){
        $this->$name = $value;
    }

    public function getNameProprio(){
    	return $this->_nom_occupants[0] ;
    }

    public function getNbrePiece(){
    	return $this->_nb_pieces;
    }

    public function getSuperficie(){
    	return $this->_superficie;
    }

    public function getEtage(){
    	return $this->_etage;
    }

    public function getJardin(){
    	return $this->_jardin;
    }

    public function getNbreOccupants(){
    	echo '<p>Nombre d\'occupants : '.$this->_nb_occupant.'</p>';
    }

    public function getNumero(){
    	return $this->_numero;
    }

    public function getPrix(){
    	return $this->_prix;
    }

    public function getPiscine(){
    	return $this->_piscine;
    }

    public function setOccupant($newOccupant){
    	$this->_nb_occupant++ ;
    	array_push($this->_nom_occupants, $newOccupant) ;
    }

    public function getNomOccupants(){

    	if($this->_nb_occupant > 1){
    		echo 'Les occupants de la villa sont :<br>';

    		foreach ($this->_nom_occupants as $value) {
    			echo '- '.$value.'<br>';
    		}
    	}else{
    		echo 'Un seul occupant dans la villa, c\'est :<br>';
    		foreach ($this->_nom_occupants as $value) {
    			echo '- '.$value.'<br>';
    		}
    	}
    }
}

* * * * * * * * * * * * * * * * * * * * * * *

  <?php

    require 'my.class.php';

    $villaZtein = new Maison(4, 300, 2, 150, 1,"Ztein", 5, 250000, false);

    var_dump($villaZtein);

    echo 'Je suis '.$villaZtein->getNameProprio().'. J\'habite la ville numéro '.$villaZtein->getNumero().', elle dispose de '.$villaZtein->getNbrePiece().' pièces pour une superficie de '.$villaZtein->getSuperficie().' m² avec '.$villaZtein->getEtage().' étages et un jardin de '.$villaZtein->getJardin().' m².<br> Nous sommes '.$villaZtein->getNbreOccupants().' occupants. Cette villa a été achetée à '.$villaZtein->getPrix().' euros et ';

        if ($villaZtein->getPiscine()){
            echo "nous avons une piscine.";
        }else{
            echo "nous n'avons pas de piscine.";
        };

    // $resume = array(
    //     'Numero de la villa'=> $villaZtein->getNumero(),
    //     'Nombre de pièces' => $villaZtein->getNbrePiece(),
    //     'Superficie en m2' => $villaZtein->getSuperficie(),
    //     'Nombre d\'étage' => $villaZtein->getEtage(),
    //     'Jardin en m2' =>  $villaZtein->getJardin(),
    //     'Prix achat' => $villaZtein->getPrix(),
    //     'Piscine' => $villaZtein->getPiscine()
    // );

    // echo '<br>';
    // echo '<br>';

    // print_r($resume) ;

    $villaZtein->setOccupant("Hale");
    $villaZtein->setOccupant("Serena");
    $villaZtein->setOccupant("Célia");
    $villaZtein->setOccupant("Megan");
    $villaZtein->getNomOccupants();
    $villaZtein->getNbreOccupants();



    var_dump($villaZtein);



    $villaJohn = new Maison(4, 300, 2, 150, 1,"John", 5, 250000, false);

    var_dump($villaJohn);


    $villaJohn->getNomOccupants();









 ?>



?>
