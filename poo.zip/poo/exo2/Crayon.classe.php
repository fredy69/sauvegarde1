<?php
class Crayon
{
 public $_couleur;
 public $_type;
 public $_quantités;

 // getters :
  public function getCouleur()
  {
    echo 'couleur : ' . $this->_marque;
  }
  public function getType()
  {
    echo 'type : ' . $this->_nombre_type;
  }
  public function getQuantités()
  {
    echo 'quantités de crayons : ' . $this->_quantités;
  }

 }

}
