<?php
class Console
{
 public $_marque;
 public $_nombre_de_jeux;
 public $_manette;


// getters :
 public function getMarque()
 {
   echo 'Marque de la console : ' . $this->_marque;
 }
 public function getNombreJeux()
 {
   echo 'Nombre de jeux : ' . $this->_nombre_jeux;
 }
 public function getManette()
 {
   echo 'Nombre de manettes : ' . $this->_manette;
 }

}
