<?php
class Personne
{
 public $_non;
 public $_prenon;
 public $_age;
 public $_sexe;
 // getters :
  public function getNon()
  {
    echo 'non: ' . $this->_non;
  }
  public function getPrenon()
  {
    echo 'prenon : ' . $this->_prenon;
  }
  public function getAge()
  {
    echo 'ages: ' . $this->_age;
  }
  public function getSexe()
  {
    echo 'sexe est.:' . $this->_sexe;
  }


}
