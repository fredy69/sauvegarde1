<?php
class Film
{
 public $_type;
 public $_duree;
 public $_acteurs;
 public $_realisateurs;
 public $_support;
 public $_note;

 // getters :
  public function getType()
  {
    echo 'type du film : ' . $this->_type;
  }
  public function getDuree()
  {
    echo 'duree du film : ' . $this->_duree;
  }
  public function getActeurs()
  {
    echo 'Les acteurs: ' . $this->_acteurs;
  }
  public function getRealisateurs()
  {
    echo 'Realisateurs est ...:' . $this->_realisateurs;
  }
  public function getSupport()
  {
    echo 'numero de série: ' . $this->_support;
  }public function getNote()
  {
    echo 'note du Film: ' . $this->_note;
  }

}
