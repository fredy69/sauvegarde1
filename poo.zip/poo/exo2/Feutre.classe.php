<?php
class Feutre
{
 public $_pointe;
 public $_couleur;
 public $_quantité;

 // getters :
  public function getPointe()
  {
    echo "Taille de pointe : " . $this->_pointe;
  }
  public function getCouleur()
  {
    echo 'couleur DU FEUTRE : ' . $this->_couleur;
  }
  public function getQuantité()
  {
    echo 'taille: ' . $this->_quantité;
  }
  

}
