<?php
class Moto
{
 public $_marque;
 public $_couleur;
 public $_plaque_d_imatriculation;

 // getters :
  public function getMarque()
  {
    echo 'marque de la moto: ' . $this->_marque;
  }
  public function getCouleur()
  {
    echo 'couleur de la moto : ' . $this->_couleur;
  }
  public function getPlaque_d_imatriculation()
  {
    echo 'numereau plaque d imatriculation: ' . $this->_plaque_d_imatriculation;
  }


}
