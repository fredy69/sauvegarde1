<?php
class Ecran
{
 public $_marque;
 public $_référence_de_l_écran;
 public $_taille;
 public $_numero_de_série;

 // getters :
  public function getMarque()
  {
    echo "référence de la marque : " . $this->_marque;
  }
  public function getReference_de_l_ecran()
  {
    echo 'référence de l écran : ' . $this->_reference_de_l_ecran;
  }
  public function getTaille()
  {
    echo 'taille: ' . $this->_taille;
  }
  public function getNumero_de_serie()
  {
    echo 'numero de série: ' . $this->_numero_de_serie;
  }



}
