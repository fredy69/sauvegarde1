
<?php
class Voiture
{
 public $_marque;
 public $_nombre_de_place_assise;
 public $_nombre_de_roue;
 public $_couleur;
 public $_plaque_d_imatriculation;
 // getters :
  public function getNombre_de_place_assise()
  {
    echo 'marque de la voiture: ' . $this->_marque;
  }
  public function getNombre_de_place_assise()
  {
    echo 'nombre de place assise : ' . $this->_nombre_de_place_assise;
  }
  public function getNombre_de_roue()
  {
    echo 'nombre_de_roue sur la voiture: ' . $this->_nombre_de_roue;
  }
  public function getCouleur()
  {
    echo 'couleur de la voiture ...:' . $this->_couleur;
  }
}public function getPlaque_d_imatriculation()
  {
    echo 'plaque_d_imatriculation DE LA VOITURE: ' . $this->_plaque_d_imatriculation;
  }

}
