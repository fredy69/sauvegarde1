Attention vous ne pouvez pas initialiser une fonction portant le même nom.

/**********************************************************************************************************************************************************
	* Exercice 1 -
  * Concevez une fonction permettant d'afficher le nom et le prénom qui auront été définis au coeur de la fonction.
  * (Nous serons obligé de modifier le nom et le prénom dans la fonction).
  * Faîtes une phrase du genre :
  *			Je m'appelle Alain Guillon !
  * Initialisé le résultat et regarder ce qu'on obtient.
	*********************************************************************************************************************************************************/
  (Audrey)

  <?php

  		    function exo1() {
        echo "Je m'appel Alain Guillon <br />";
    }
    exo1();

    ---------------------------

        function afficherNom(){
          $nom = 'Norris';
          $prenom = 'Chuck';

          echo 'I\'am ' . $prenom . ' ' . $nom . '<br />';
        }

afficherNom();
  /**********************************************************************************************************************************************************
	* Exercice 2 -
  * Concevez une fonction permettant d'afficher le nom et le prénom en paramètre
  afin de pouvoir directement lors de l'initilisation de notre fonction
  * définir en brut l'identité de la personne.
	*********************************************************************************************************************************************************/

function sePresenter($prenom, $nom) {
  $str = 'Bonjour, tu es ' . $prenom . ' ' . $nom . ', n\'est ce pas ?';
  return $str;
}

$phrase = sePresenter('Guillaume', 'Poncet');
echo $phrase;

  /**********************************************************************************************************************************************************
	* Exercice 3 -
  * Concevez une fonction avec le nom et le prénom définit en dehors de la fonction.
  * (Probabilité d'erreur extrêmement élevé. Si c'est le cas commenté, c'est peut être juste.).
	*********************************************************************************************************************************************************/
      $prenom = "Alain";
      $nom = "Guillon";
      function exo3() {
          echo 'Je m\'appelle ' . $prenom . ' ' . $nom . '.';
      }
      exo3();
  /**********************************************************************************************************************************************************
	* Exercice 4 -
  * Concevez une fonction qui cette fois ci grâce à globals permettra de récupérer
  le nom et le prénom qui serait définit en dehors de la fonction.
  *	Affiché toujours une phrase.
	*********************************************************************************************************************************************************/
  $prenom = "Alain";
      $nom = "Guillon";
      function exo3() {
        	// global explique qu'on récupère une variable qui est définie EN DEHORS de la fonction MERCI GUIGUI
        	$GLOBALS['prenom'];
        	global $nom;
          echo 'Je m\'appelle ' . $GLOBALS['prenom'] . ' ' . $nom . '.';
      }
      exo3();
  /**********************************************************************************************************************************************************
	* Exercice 5 -
  * Définissez une constante nom et une constante prénom.
  * Récupérer l'information dans votre fonction.
  * Faîte en sorte d'afficher le résultat lors de l'initialisation de votre fonction.
	*********************************************************************************************************************************************************/
define('PRENOM', 'Jean-Pierre');
define('NOM', 'Perdreau');

function sosie() {
  $str = PRENOM . ' ' . NOM . ' est le sosie d\'une célébrité !';
  echo $str;
}

sosie();
  /**********************************************************************************************************************************************************
	* Exercice 6 -
  * Concevez une fonction permettant de calculer le nombre d'élèves dans chaque classe d'un collège.
  *	Sachant que ce collège accueil 4960 élèves dans 180 classes.
	*********************************************************************************************************************************************************/

function calcul_Eleve(int $nb_eleves, int $nb_classes) {
  $result = $nb_eleves/$nb_classes;
  return round($result);
}

echo 'Il y a ' . calcul_Eleve(4960, 180) . ' élèves par classe<br />';

  /**********************************************************************************************************************************************************
	* Exercice 7 -
  * Concevez une fonction permettant selon le nombre indiqué, de calculer automatiquement le prix TTC d'un article.
  * sachant que la TVA sera définit dans une constante.
  * Indiquer un paramètre qui sera le prix du second paramètre qui représentera votre objet.
	*********************************************************************************************************************************************************/
  define('TVA', 1.20);
  $prix = 20;

  function calcul_Prix(int $prix_du_moment){
    $result = $prix_du_moment * TVA;
    return $result;
  }

	echo $prix . '€ HT donne ' . calcul_Prix($prix) . '€ TTC<br />';

	------------------------------------

    define('TVA', 20);
      function exo7($prix = '0', $obj) {
      $resultat = $prix * TVA / 100;

      echo 'Mon ' . $obj . ' coûte avec la TVA : ' . $resultat . '€';
  		}
    exo7(4.8,'stylo');

  /*********************************************************************************************************************************************************
	* Exercice 8 -
  * Concevez une fonction qui selon le nombre défini en paramètre, permettra en
  retour d'avoir le nombre d'élève présent dans notre cours.
	*********************************************************************************************************************************************************/
  define('EFFECTIF', 15);

    function eleves_Presents(int $absents){
      $result = EFFECTIF - $absents;
      return $result;
    }

    echo 'Il y a ' . eleves_Presents(6) . ' élèves présents. Appelle vite le Pôle Emploi !';
  /*********************************************************************************************************************************************************
	* Exercice 9 -
  * Définir une constante argent qui sera initialisé à 0.
  * Dans une fonction lorsqu'on définira en paramètre un montant, nous aurons le montant qui changera automatiquement.
  * Quand nous allons à nouveau initialiser notre fonction,
  * nous aurons le prix qui aura été gardé en mémoire grâce au mot clé "static".
  * Ainsi a chaque fois le montant évoluera le montant de base ne sera jamais identique.
	*********************************************************************************************************************************************************/
  $argent = 0;

function changer_Montant(int $new){
  global $argent;
  $argent += $new;
  static $argent;
}

changer_Montant(50);
echo $argent;

changer_Montant(60);
echo $argent;














  
