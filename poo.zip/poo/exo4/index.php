<?php
include 'function.php';

êresult = [];
array_push($result,
    coucou(),
    sePresenter('fred','greg'),
    firstlady(),
    sosie(),
    carre(9),
    plusPetit(50, 50),
    calculette(50.95,`*`5)
);
include 'index.phtml';
