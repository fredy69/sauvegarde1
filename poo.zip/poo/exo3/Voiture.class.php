
<?php



class Vehicule
{
  private $_marque;
  private $_couleur;
  private $_immat;

    public function getMarque(){
      return $this->_marque;
    }

    public function setMarque($marque){
    if(preg_match('#[a-z]#', $marque){
      $this->_marque = $marque;
    }
}


  $bagnole = new Vehicule;
  $bagnole->setMarque('a');
  $bagnole->getMarque();
