<?php
class Club
{
 public $_équipe;
 public $_joueur;
 public $_poste;
 public $_role;

// getters :
 public function getEquipe()
 {
   echo "non de l'équipe  : " . $this->_equipe;
 }
 public function getJoueur()
 {
   echo 'Nombre de joueur : ' . $this->_joueur;
 }
 public function getPoste()
 {
   echo 'posissionement : ' . $this->_poste;
 }
 public function getRole()
 {
   echo 'role: ' . $this->_role;
 }

}
class Vehicule
{
  private $_marque;
  private $_couleur;
  private $_immat;
  ...

    public function setMarque($marque){
    if(preg_match('#[a-z]#', $marque){
      $this->_marque = $marque;
    }
  }


  $bagnole = new Vehicule;
    $bagnole->_marque = 'GroSchleu';
    $bagnole->setMarque('GroSchleu');

    $bagnole->_mail = 'sdfsdfqsd';
