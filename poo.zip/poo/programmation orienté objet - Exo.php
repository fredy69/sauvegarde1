/*****************************************************************************************************************************
 * Exercice 01
 * Créer 10 classes différentes dans le même fichier.
 * 		- TV
 *		-	Voiture
 *		- Crayon
 *		-	Moto
 *		-	Ecran
 *		-	Feutre
 *		- film
 *		- console
 *		- football
 *		- club
 *		- personne
 *****************************************************************************************************************************/

<?php

// On définit une class qui est un "plan pour construire un objet
class Guillaume
{
  // ceci sont des propriétés ou atttributs
  private $_dignite = 0;
  private $_barbe_de_trois_jours;

  // les fonctions déclarés à l'intérieur d'un class sont appelées méthodes
  public function fairePousserBarbe(){
    $this->_barbe_de_trois_jours = 5;
    echo 'Ma barbe a poussé de ' . $this->_barbe_de_trois_jours . ' cms<br />' ;
  }

  public function conclure(){
    echo 'Voilà voilà<br />';
  }

  public function seGratterLeVentre(){
    echo 'grat...grat...<br />';
  }
}


$guillaume = new Guillaume;

$guillaume->conclure();

$guillaume->fairePousserBarbe();
?>
