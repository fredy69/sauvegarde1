/*****************************************************************************************************************************
 * Exercice 01
 * Créer 10 classes différentes dans le même fichier.
 * 		- TV
 *		-	Voiture
 *		- Crayon
 *		-	Moto
 *		-	Ecran
 *		-	Feutre
 *		- film
 *		- console
 *		- football
 *		- club
 *		- personne
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 02
 * Découper nos 11 classes dans des fichiers spécifique */
    TV.class.php
 		Voiture.class.php
 		Crayon.class.php
 		Moto.class.php
 		Ecran.class.php
 		Feutre.class.php
    Film.class.php
    Console.class.php
   	Football.class.php
 		Club.class.php
    Personne.class.php
 /******************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 03
 * Définir des propriétées pour toutes nos classes. (Elles seront toutes publics)
 * 		- TV (marque / taille / note / reference / numero de série)
 *		-	Voiture (marque / nombre de place assise / nombre de roue / couleur / plaque d'imatriculation)
 *		- Crayon (couleur / type / quantités)
 *		-	Moto (marque / couleur / plaque d'imatriculation)
 *		-	Ecran (marque / référence de l'écran / taille / numéro de série)
 *		-	Feutre (pointe / couleur / quantité)
 *		- Film ( type / duree / acteurs / réalisateurs / support / note )
 *		- Console ( marque / nombre de jeux / manette )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur / poste / role )
 *		- Personne ( nom / prénom / age / sexe )
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 04
 * Afficher avec écho une phrase reprenant toutes nos informations dans plusieurs méthodes différente.
 * 		- TV ( marque / taille / note / reference / numero de série)
 *		-	Voiture (marque / nombre de place assise / nombre de roue / couleur / plaque d'imatriculation)
 *		- Crayon (couleur / type / quantités)
 *		-	Moto (marque / couleur / plaque d'imatriculation)
 *		-	Ecran (marque / référence de l'écran / taille / numéro de série)
 *		-	Feutre (pointe / couleur / quantité)
 *		- Film ( type / duree / acteurs / réalisateurs / support / note )
 *		- Console ( marque / nombre de jeux / manette )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur / poste / role )
 *		- Personne ( nom / prénom / age / sexe )
 *****************************************************************************************************************************/
      echo $tv->_marque;
/*****************************************************************************************************************************
 * Exercice 05
 * Reprenez l'intégralité des méthodes créer précédemment, sur chaque propriété publics,
 passé celles qui sont afficher ci-dessous en private
 * Et récupérer le contenu avec $this. (par défaut elle sont public).
 * 		- TV ( marque / reference / numero de série)
 *		-	Voiture (marque / couleur / plaque d'imatriculation)
 *		- Crayon (couleur / type)
 *		-	Moto (marque / couleur)
 *		-	Ecran (marque / numéro de série)
 *		-	Feutre (couleur)
 *		- Film ( duree / acteurs / note )
 *		- Console ( marque / nombre de jeux )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur )
 *		- Personne ( nom / prénom )
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 06
 * Concevez des getters pour chaque objets et surtout pour toutes les propriétés.
 * 		- TV (marque / taille / note / reference / numero de série)
 *		-	Voiture (marque / nombre de place assise / nombre de roue / couleur / plaque d'imatriculation)
 *		- Crayon (couleur / type / quantités)
 *		-	Moto (marque / couleur / plaque d'imatriculation)
 *		-	Ecran (marque / référence de l'écran / taille / numéro de série)
 *		-	Feutre (pointe / couleur / quantité)
 *		- Film ( type / duree / acteurs / réalisateurs / support / note )
 *		- Console ( marque / nombre de jeux / manette )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur / poste / role )
 *		- Personne ( nom / prénom / age / sexe )
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 07
 * Manipuler les propriétés en créant des propriétés protected. (Au choix)
 * 		- TV (marque / taille / note / reference / numero de série)
 *		-	Voiture (marque / nombre de place assise / nombre de roue / couleur / plaque d'imatriculation)
 *		- Crayon (couleur / type / quantités)
 *		-	Moto (marque / couleur / plaque d'imatriculation)
 *		-	Ecran (marque / référence de l'écran / taille / numéro de série)
 *		-	Feutre (pointe / couleur / quantité)
 *		- Film ( type / duree / acteurs / réalisateurs / support / note )
 *		- Console ( marque / nombre de jeux / manette )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur / poste / role )
 *		- Personne ( nom / prénom / age / sexe )
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 08
 * Concevez un héritage selon votre logique afin de mieux s'organiser.
 * Exemple :
 *		- Nouvelle class Vehicule (class parent )
 *				- Voiture (marque / nombre de place assise / nombre de roue / couleur / plaque d'imatriculation) - (class enfant)
 *				- Moto (marque / couleur / plaque d'imatriculation) - (class enfant)
 *
 * 		- TV (marque / taille / note / reference / numero de série)
 *		- Crayon (couleur / type / quantités)
 *		-	Ecran (marque / référence de l'écran / taille / numéro de série)
 *		-	Feutre (pointe / couleur / quantité)
 *		- Film ( type / duree / acteurs / réalisateurs / support / note )
 *		- Console ( marque / nombre de jeux / manette )
 *		- Football ( championnat )
 *		- Club ( équipe / joueur / poste / role )
 *		- Personne ( nom / prénom / age / sexe )
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 09
 * Concevez une classe qui n'obtiendra jamais de parent ainsi que son opposé, soit une class qui n'aura jamais d'enfant.
 (abstract / final)
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 10
 * Reprenez les classes que vous avez créer et créer de l'informations que vous allez récupérer dans des classes enfants
 * Définissez une histoire rapide que vous affichez grâce à ces classes :D
 *****************************************************************************************************************************/

/*****************************************************************************************************************************
 * Exercice 11
 * Essayer de concevoir une class PDO qui nous permettrait de créer et concevoir une connexion à une base de donnée.
 * Nous mettrons en commun le shéma utiliser.
 *****************************************************************************************************************************/
















<?php

// On définit une class qui est un "plan" pour construire un objet
class Guillaume
{
  // ceci sont des propriétés ou attributs, avant on définit sa visibilité (private, public ou protected)
  private $_dignite = 0;
  private $_barbe_de_trois_jours;

  // les fonctions déclarés à l'intérieur d'un class sont appelées méthodes
  // ici une méthode qui définit une propriété s'appelle un "setter" (setBarbe(5), setCouleur(rouge), ...)
  public function setBarbe($longueur){
    // ici on fait appel à la propiété $_barbe_de_trois_jours en précisant qu'on est dans l'objet courant par : $this->
    $this->_barbe_de_trois_jours = $longueur;
    echo 'Ma barbe a poussé de ' . $this->_barbe_de_trois_jours . ' cms<br />' ;
  }

  	// une méthode qui renvoie la valeur d'une propriété s'appelle un "getter" (getBarbe() renvoie : Ma barbe fait 5cms)
    public function getBarbe(){
    echo 'Ma barbe fait ' . $this->_barbe_de_trois_jours . ' cms<br />' ;
  }

  public function conclure(){
    echo 'Voilà voilà<br />';
  }

  public function seGratterLeVentre(){
    echo 'grat...grat...<br />';
  }
}

// on instancie une class = on crée un nouvel objet qui a toutes les propriétés et les méthodes définies avant
$guillaume = new Guillaume;

// on appelle une méthode de l'objet $guillaume
$guillaume->conclure();

$exemple = 15;
$guillaume->setBarbe($exemple);
?>
