foreach($array as $value) {

}
