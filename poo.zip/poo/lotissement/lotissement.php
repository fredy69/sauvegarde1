<?php

abstract class LotissementAbstract
{
	const ADRESSE = 'rue Pôle Pixel';
  const VILLE = 'Villeurbanne';
  const CODE_POSTAL = 69100;
}

class Maison extends LotissementAbstract
{
    private $_nb_pieces;
    private $_superficie;
    private $_etage;
    private $_jardin;
    private $_nb_occupant;
    private $_numero = 1;
    private $_prix;
    private $_piscine;

    public function __construct($piece, $superficie, $etage, $jardin, $occupant, $prix, $piscine = false)
    {
        $this->_nb_pieces = $piece;
        $this->_superficie = $superficie;
        $this->_etage = $etage;
        $this->_jardin = $jardin;
        $this->_nb_occupant = $occupant;
        $this->_prix;
        $this->_piscine = $piscine;
    }

    public function __get($name){
        $this->$name;
    }
    public function __set($name, $value){
        $this->$name = $value;
    }
}

// Numéro des villa / maisons.
01 - Rudy
02 - Lenny
03 - Christophe
04 - Célia
05 - Ztain
06 - Hasmik
07 - Audrey
08 - Nouh
09 - Julien
10 - Frédéric
11 - Guillaume
12 - Yorick
13 - Jean-Patrice

Chaque class sera dans un fichier spécifique.

// Nombre d'occupant.
(Chaque occupant sera dans un fichier spécifique).

Afficher dans un index le contenu de votre maison.
Grossomodo vous allez avoir un tableau qui affichera le contenu global de votre habitation.

Nom des champs du tableau :
	- Numéro
  	-> Le numéro du lotissement
  - Propriétaire
  	-> Le nom du propriétaire
  - Nombre d'occupant
  	-> Le nombre d'occupant
  - Prix
  	-> Le prix de la maison
  - En savoir plus.
  	-> Un lien vers une page qui contiendrai tout le contenu de vos données.
