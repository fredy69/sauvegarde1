fonction carré($nombres)
}
$result = $nombres*$nombres;
return $result;
}


fonction pluspetit(int $nomb1, int $nomb2)
}
	if ($nomb1>$nomb2) {
		return $nomb2,'petit';
		}
		else ($nomb1>$nomb2){
			return $nomb2.'petit';
		}
		else return;
		}
